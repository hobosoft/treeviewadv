using System.Windows.Forms;

namespace SampleApp
{
	public partial class MainForm : Form
	{
		public MainForm()
		{
			InitializeComponent();
		}
	}
}